<?php
class Conyuge extends AppModel {
	//public $name = 'Escalafon';
	//public $useDbConfig = 'msSqlPersonas';	
}