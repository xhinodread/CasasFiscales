<?
class Destino extends AppModel {
	
}
?>