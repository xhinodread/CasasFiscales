<?php
class Conyuge extends AppModel {
	//public $name = 'Conyuge';
	
}